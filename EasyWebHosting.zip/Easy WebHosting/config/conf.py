import os;
import time;
os.system("title Easy WebHosting")
print("===============================================================================")
print("Hello Local Dev :D")
answer= input("Do you want to host your website? y or n? ")
if answer == "y":
    print("Hosting your website")
    time.sleep(1);
    os.system("cls")
    print("Hosting your website.")
    time.sleep(1);
    os.system("cls")
    print("Hosting your website..")
    time.sleep(1);
    os.system("cls")
    print("Hosting your website...")
    time.sleep(1);
    print("Successfully hosted website :D");
    time.sleep(1)
    os.system("ssh -R 80:localhost:80 nokey@localhost.run")
